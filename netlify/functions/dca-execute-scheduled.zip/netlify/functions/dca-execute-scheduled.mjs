
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// netlify/functions/dca-execute-scheduled.mts
import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  alerts: () => alerts,
  dcaBots: () => dcaBots,
  dcaExecutions: () => dcaExecutions,
  learnClicks: () => learnClicks,
  learnInputs: () => learnInputs,
  learnKeywords: () => learnKeywords,
  learnSuggestions: () => learnSuggestions,
  runs: () => runs
});
import { sqliteTable, integer, text, real, index } from "drizzle-orm/sqlite-core";
var runs = sqliteTable("runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  shortId: text("short_id").notNull().unique(),
  prompt: text("prompt").notNull(),
  planResult: text("plan_result", { mode: "json" }).notNull(),
  toolResult: text("tool_result", { mode: "json" }),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
  userId: integer("user_id"),
  runLabel: text("run_label"),
  meta: text("meta", { mode: "json" })
});
var learnInputs = sqliteTable("learn_inputs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  text: text("text").notNull(),
  intent: text("intent"),
  createdAt: integer("created_at").notNull()
});
var learnClicks = sqliteTable("learn_clicks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  text: text("text").notNull(),
  createdAt: integer("created_at").notNull()
});
var learnKeywords = sqliteTable("learn_keywords", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  keyword: text("keyword").notNull().unique(),
  score: real("score").notNull(),
  updatedAt: integer("updated_at").notNull()
});
var learnSuggestions = sqliteTable("learn_suggestions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  text: text("text").notNull().unique(),
  weight: real("weight").notNull(),
  source: text("source").notNull(),
  createdAt: integer("created_at").notNull()
});
var alerts = sqliteTable("alerts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  email: text("email").notNull(),
  conditionType: text("condition_type").notNull().default("gas_below_usd_per_100k"),
  thresholdUsd: real("threshold_usd").notNull(),
  minGasUnits: integer("min_gas_units").notNull().default(1e5),
  verified: integer("verified", { mode: "boolean" }).notNull().default(false),
  verifyToken: text("verify_token").unique(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  lastNotifiedAt: integer("last_notified_at"),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull()
}, (table) => ({
  emailIdx: index("alerts_email_idx").on(table.email),
  activeIdx: index("alerts_active_idx").on(table.active),
  verifiedIdx: index("alerts_verified_idx").on(table.verified)
}));
var dcaBots = sqliteTable("dca_bots", {
  id: text("id").primaryKey(),
  // dca_abc123
  userId: text("user_id").notNull(),
  // User identifier (wallet address or user ID)
  name: text("name").notNull(),
  buyTokenMint: text("buy_token_mint").notNull(),
  // Token to buy (e.g., SOL mint address)
  buyTokenSymbol: text("buy_token_symbol").notNull(),
  // For display (e.g., "SOL")
  paymentTokenMint: text("payment_token_mint").notNull(),
  // Token to pay with (e.g., USDC)
  paymentTokenSymbol: text("payment_token_symbol").notNull(),
  // For display
  amountUsd: real("amount_usd").notNull(),
  // Amount in USD to spend per execution
  frequency: text("frequency").notNull(),
  // 'daily', 'weekly', 'biweekly', 'monthly'
  startDate: integer("start_date").notNull(),
  // Unix timestamp
  endDate: integer("end_date"),
  // Optional end date
  maxSlippage: real("max_slippage").notNull().default(0.5),
  // Percentage (0.5 = 0.5%)
  status: text("status").notNull().default("active"),
  // 'active', 'paused', 'completed', 'failed'
  walletAddress: text("wallet_address").notNull(),
  // User's wallet public key
  nextExecution: integer("next_execution"),
  // Unix timestamp for next scheduled execution
  executionCount: integer("execution_count").notNull().default(0),
  totalInvested: real("total_invested").notNull().default(0),
  // Total USD spent
  totalReceived: real("total_received").notNull().default(0),
  // Total tokens received
  // Phase 2 fields
  delegationAmount: real("delegation_amount"),
  // Approved delegation amount in payment token
  delegationExpiry: integer("delegation_expiry"),
  // When delegation expires
  lastExecutionAttempt: integer("last_execution_attempt"),
  // Last execution attempt timestamp
  failedAttempts: integer("failed_attempts").notNull().default(0),
  // Consecutive failures
  pauseReason: text("pause_reason"),
  // Why bot was paused
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull()
}, (table) => ({
  userIdx: index("dca_bots_user_idx").on(table.userId),
  walletIdx: index("dca_bots_wallet_idx").on(table.walletAddress),
  statusIdx: index("dca_bots_status_idx").on(table.status),
  nextExecutionIdx: index("dca_bots_next_execution_idx").on(table.nextExecution)
}));
var dcaExecutions = sqliteTable("dca_executions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  botId: text("bot_id").notNull().references(() => dcaBots.id, { onDelete: "cascade" }),
  executedAt: integer("executed_at").notNull(),
  paymentAmount: real("payment_amount").notNull(),
  // Amount of payment token spent
  receivedAmount: real("received_amount").notNull(),
  // Amount of buy token received
  price: real("price").notNull(),
  // Execution price (payment per buy token)
  slippage: real("slippage").notNull(),
  // Actual slippage percentage
  txSignature: text("tx_signature"),
  // Solana transaction signature
  gasUsed: real("gas_used").notNull(),
  // SOL spent on gas
  status: text("status").notNull(),
  // 'success', 'failed', 'pending'
  errorMessage: text("error_message"),
  jupiterQuoteId: text("jupiter_quote_id"),
  // For debugging
  // Phase 2 fields
  errorCode: text("error_code"),
  // Error type if failed
  retryCount: integer("retry_count").notNull().default(0),
  // How many retries
  jupiterRoute: text("jupiter_route"),
  // JSON of swap route used
  createdAt: integer("created_at").notNull()
}, (table) => ({
  botIdx: index("dca_executions_bot_idx").on(table.botId),
  statusIdx: index("dca_executions_status_idx").on(table.status),
  executedAtIdx: index("dca_executions_executed_at_idx").on(table.executedAt)
}));

// netlify/functions/dca-execute-scheduled.mts
import { eq, and, lte } from "drizzle-orm";

// src/lib/jupiter-executor.ts
async function getJupiterQuote(inputMint, outputMint, amountInSmallestUnit, slippageBps = 50) {
  try {
    const url = new URL("https://quote-api.jup.ag/v6/quote");
    url.searchParams.append("inputMint", inputMint);
    url.searchParams.append("outputMint", outputMint);
    url.searchParams.append("amount", amountInSmallestUnit.toString());
    url.searchParams.append("slippageBps", slippageBps.toString());
    url.searchParams.append("onlyDirectRoutes", "false");
    url.searchParams.append("asLegacyTransaction", "false");
    const response = await fetch(url.toString(), {
      headers: {
        "Accept": "application/json"
      }
    });
    if (!response.ok) {
      const error = await response.text();
      console.error("Jupiter quote error:", error);
      return null;
    }
    const quote = await response.json();
    return quote;
  } catch (error) {
    console.error("Failed to get Jupiter quote:", error);
    return null;
  }
}

// netlify/functions/dca-execute-scheduled.mts
var { dcaBots: dcaBots2, dcaExecutions: dcaExecutions2 } = schema_exports;
var dca_execute_scheduled_default = async (req) => {
  const startTime = Date.now();
  console.log("[DCA Scheduled Function] Starting execution check...");
  try {
    const { next_run } = await req.json();
    console.log(`[DCA Scheduled Function] Next scheduled run: ${next_run}`);
    const url = process.env.TURSO_CONNECTION_URL;
    const authToken = process.env.TURSO_AUTH_TOKEN;
    if (!url || !authToken) {
      console.error("[DCA Scheduled Function] Missing database credentials");
      return new Response(JSON.stringify({
        error: "Database credentials not configured"
      }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    const client = createClient({ url, authToken });
    const db = drizzle(client, { schema: schema_exports });
    const now = Date.now();
    const dueBots = await db.select().from(dcaBots2).where(
      and(
        eq(dcaBots2.status, "active"),
        lte(dcaBots2.nextExecution, now)
      )
    ).limit(10);
    console.log(`[DCA Scheduled Function] Found ${dueBots.length} bots due for execution`);
    if (dueBots.length === 0) {
      return new Response(JSON.stringify({
        success: true,
        message: "No bots due for execution",
        executedCount: 0,
        timestamp: now,
        duration: Date.now() - startTime
      }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
    const results = await Promise.allSettled(
      dueBots.map((bot) => executeBot(bot, db))
    );
    const successCount = results.filter((r) => r.status === "fulfilled" && r.value?.success).length;
    const failureCount = results.length - successCount;
    const duration = Date.now() - startTime;
    console.log(`[DCA Scheduled Function] Complete in ${duration}ms: ${successCount} success, ${failureCount} failures`);
    return new Response(JSON.stringify({
      success: true,
      message: `Processed ${dueBots.length} bots`,
      executedCount: successCount,
      failedCount: failureCount,
      timestamp: now,
      duration,
      nextRun: next_run
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("[DCA Scheduled Function] Fatal error:", error);
    return new Response(JSON.stringify({
      error: "Execution failed",
      details: error.message,
      duration: Date.now() - startTime
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
async function executeBot(bot, db) {
  const startTime = Date.now();
  console.log(`[Bot ${bot.id}] Starting execution for ${bot.name}`);
  try {
    const USDC_DECIMALS = 6;
    const amountInSmallestUnit = Math.floor(bot.amountUsd * Math.pow(10, USDC_DECIMALS));
    const slippageBps = Math.floor((bot.maxSlippage || 0.5) * 100);
    console.log(`[Bot ${bot.id}] Getting Jupiter quote...`);
    const quote = await getJupiterQuote(
      bot.paymentTokenMint,
      bot.buyTokenMint,
      amountInSmallestUnit,
      slippageBps
    );
    if (!quote) {
      console.error(`[Bot ${bot.id}] Failed to get quote`);
      await recordFailedExecution(bot, db, "Failed to get Jupiter quote");
      return { success: false, error: "Failed to get quote" };
    }
    const quotedSlippagePct = quote.slippageBps / 100;
    if (quotedSlippagePct > bot.maxSlippage) {
      console.warn(`[Bot ${bot.id}] Slippage too high: ${quotedSlippagePct}% > ${bot.maxSlippage}%`);
      await skipExecution(bot, db, "Slippage too high");
      return { success: false, error: "Slippage too high" };
    }
    console.log(`[Bot ${bot.id}] Simulating execution...`);
    const executionResult = {
      success: true,
      txSignature: `sim_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      inAmount: parseFloat(quote.inAmount),
      outAmount: parseFloat(quote.outAmount),
      price: parseFloat(quote.inAmount) > 0 ? parseFloat(quote.outAmount) / parseFloat(quote.inAmount) : 0,
      slippage: quotedSlippagePct
    };
    await db.insert(dcaExecutions2).values({
      botId: bot.id,
      executedAt: Date.now(),
      paymentAmount: bot.amountUsd,
      receivedAmount: executionResult.outAmount / Math.pow(10, 9),
      price: executionResult.price,
      slippage: executionResult.slippage,
      txSignature: executionResult.txSignature,
      gasUsed: 5e-6,
      status: "success",
      jupiterQuoteId: quote.routePlan?.[0]?.swapInfo?.ammKey || null,
      createdAt: Date.now()
    });
    const newTotalInvested = bot.totalInvested + bot.amountUsd;
    const newTotalReceived = bot.totalReceived + executionResult.outAmount / Math.pow(10, 9);
    const newExecutionCount = bot.executionCount + 1;
    const newNextExecution = calculateNextExecution(bot);
    await db.update(dcaBots2).set({
      executionCount: newExecutionCount,
      totalInvested: newTotalInvested,
      totalReceived: newTotalReceived,
      nextExecution: newNextExecution,
      lastExecutionAttempt: Date.now(),
      failedAttempts: 0,
      updatedAt: Date.now()
    }).where(eq(dcaBots2.id, bot.id));
    const duration = Date.now() - startTime;
    console.log(`[Bot ${bot.id}] Success in ${duration}ms`);
    return { success: true };
  } catch (error) {
    console.error(`[Bot ${bot.id}] Execution failed:`, error);
    await recordFailedExecution(bot, db, error.message);
    return { success: false, error: error.message };
  }
}
async function recordFailedExecution(bot, db, errorMessage) {
  try {
    await db.insert(dcaExecutions2).values({
      botId: bot.id,
      executedAt: Date.now(),
      paymentAmount: bot.amountUsd,
      receivedAmount: 0,
      price: 0,
      slippage: 0,
      txSignature: null,
      gasUsed: 0,
      status: "failed",
      errorMessage,
      createdAt: Date.now()
    });
    const newFailedAttempts = (bot.failedAttempts || 0) + 1;
    const shouldPause = newFailedAttempts >= 3;
    await db.update(dcaBots2).set({
      lastExecutionAttempt: Date.now(),
      failedAttempts: newFailedAttempts,
      status: shouldPause ? "paused" : bot.status,
      pauseReason: shouldPause ? `Failed ${newFailedAttempts} times: ${errorMessage}` : bot.pauseReason,
      updatedAt: Date.now()
    }).where(eq(dcaBots2.id, bot.id));
    if (shouldPause) {
      console.warn(`[Bot ${bot.id}] Auto-paused after ${newFailedAttempts} failures`);
    }
  } catch (error) {
    console.error(`[Bot ${bot.id}] Failed to record execution failure:`, error);
  }
}
async function skipExecution(bot, db, reason) {
  try {
    console.log(`[Bot ${bot.id}] Skipping execution: ${reason}`);
    const newNextExecution = calculateNextExecution(bot);
    await db.update(dcaBots2).set({
      nextExecution: newNextExecution,
      lastExecutionAttempt: Date.now(),
      updatedAt: Date.now()
    }).where(eq(dcaBots2.id, bot.id));
  } catch (error) {
    console.error(`[Bot ${bot.id}] Failed to skip execution:`, error);
  }
}
function calculateNextExecution(bot) {
  const now = Date.now();
  const frequency = bot.frequency;
  switch (frequency) {
    case "daily":
      return now + 24 * 60 * 60 * 1e3;
    case "weekly":
      return now + 7 * 24 * 60 * 60 * 1e3;
    case "biweekly":
      return now + 14 * 24 * 60 * 60 * 1e3;
    case "monthly":
      return now + 30 * 24 * 60 * 60 * 1e3;
    default:
      return now + 24 * 60 * 60 * 1e3;
  }
}
var config = {
  schedule: "*/5 * * * *"
};
export {
  config,
  dca_execute_scheduled_default as default
};
